/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.rocketmq.client.java.impl.consumer;

import org.apache.rocketmq.shaded.com.google.common.util.concurrent.Futures;
import org.apache.rocketmq.shaded.com.google.common.util.concurrent.ListenableFuture;
import org.apache.rocketmq.shaded.com.google.common.util.concurrent.MoreExecutors;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.ScheduledExecutorService;
import org.apache.rocketmq.client.apis.consumer.ConsumeResult;
import org.apache.rocketmq.client.apis.consumer.MessageListener;
import org.apache.rocketmq.client.java.hook.MessageInterceptor;
import org.apache.rocketmq.client.java.message.MessageViewImpl;
import org.apache.rocketmq.client.java.misc.ClientId;
import org.apache.rocketmq.shaded.org.slf4j.Logger;
import org.apache.rocketmq.shaded.org.slf4j.LoggerFactory;

class FifoConsumeService extends ConsumeService {
    private static final Logger log = LoggerFactory.getLogger(FifoConsumeService.class);
    private final boolean enableFifoConsumeAccelerator;

    public FifoConsumeService(ClientId clientId, String consumerGroup, MessageListener messageListener,
        ExecutorService consumptionExecutor, MessageInterceptor messageInterceptor,
        ScheduledExecutorService scheduler, boolean enableFifoConsumeAccelerator) {
        super(clientId, consumerGroup, messageListener, consumptionExecutor, messageInterceptor, scheduler);
        this.enableFifoConsumeAccelerator = enableFifoConsumeAccelerator;
    }

    @Override
    public void consume(ProcessQueue pq, List<MessageViewImpl> messageViews) {
        if (!enableFifoConsumeAccelerator || messageViews.size() <= 1) {
            consumeIteratively(pq, messageViews.iterator());
            return;
        }
        Map<String, List<MessageViewImpl>> messageViewsGroupByGroupKey = new HashMap<>();
        for (MessageViewImpl messageView : messageViews) {
            // Group messages by group key. Default to null-key group for unkeyed messages.
            String groupKey = getMessageGroupKey(messageView);
            messageViewsGroupByGroupKey.computeIfAbsent(groupKey, k -> new ArrayList<>()).add(messageView);
        }
        log.debug("FifoConsumeService parallel consume, messageViewsNum={}, groupNum={}", messageViews.size(),
            messageViewsGroupByGroupKey.size());

        messageViewsGroupByGroupKey.values().forEach(list -> consumeIteratively(pq, list.iterator()));
    }

    /**
     * Get the group key for the given message view.
     * Subclasses should override this method to provide different grouping logic.
     */
    protected String getMessageGroupKey(MessageViewImpl messageView) {
        return messageView.getMessageGroup().orElse(null);
    }

    /**
     * Consume messages iteratively using the provided iterator.
     * This method handles corrupted messages and continues processing the next valid message.
     */
    protected void consumeIteratively(ProcessQueue pq, Iterator<MessageViewImpl> iterator) {
        MessageViewImpl messageView = getNextValidMessage(pq, iterator);
        if (messageView == null) {
            return;
        }
        final ListenableFuture<ConsumeResult> future0 = consume(messageView);
        ListenableFuture<Void> future = Futures.transformAsync(future0, result -> pq.eraseFifoMessage(messageView,
            result), MoreExecutors.directExecutor());
        future.addListener(() -> consumeIteratively(pq, iterator), MoreExecutors.directExecutor());
    }

    /**
     * Get the next valid message from the iterator.
     * Skip corrupted messages and return the first valid one.
     * Returns null if there are no more messages.
     */
    protected MessageViewImpl getNextValidMessage(ProcessQueue pq, Iterator<MessageViewImpl> iterator) {
        while (iterator.hasNext()) {
            final MessageViewImpl messageView = iterator.next();
            if (messageView.isCorrupted()) {
                // Discard corrupted message.
                log.error("Message is corrupted for FIFO consumption, prepare to discard it, mq={}, messageId={}, "
                    + "clientId={}", pq.getMessageQueue(), messageView.getMessageId(), clientId);
                pq.discardFifoMessage(messageView);
                continue;
            }
            return messageView;
        }
        return null;
    }
}
